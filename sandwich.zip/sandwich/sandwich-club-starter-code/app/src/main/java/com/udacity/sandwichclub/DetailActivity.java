package com.udacity.sandwichclub;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;
import com.udacity.sandwichclub.model.Sandwich;
import com.udacity.sandwichclub.utils.JsonUtils;

import java.util.List;

public class DetailActivity extends AppCompatActivity {

    public static final String EXTRA_POSITION = "extra_position";
    private static final int DEFAULT_POSITION = -1;
    private Sandwich sandwich;

    //view variables to populate view
    private TextView placeOfOrigin;
    private TextView description ;
    private TextView ingredients;
    private TextView alsoKnowAs;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        //getting view id's
        ImageView ingredientsIv = findViewById(R.id.image_iv);
         placeOfOrigin = findViewById(R.id.origin_tv);
         description = findViewById(R.id.description_tv);
         ingredients = findViewById(R.id.ingredients_tv);
         alsoKnowAs = findViewById(R.id.also_known_tv);

        Intent intent = getIntent();
        if (intent == null) {
            closeOnError();
        }

        int position = intent.getIntExtra(EXTRA_POSITION, DEFAULT_POSITION);
        if (position == DEFAULT_POSITION) {
            // EXTRA_POSITION not found in intent
            closeOnError();
            return;
        }

        String[] sandwiches = getResources().getStringArray(R.array.sandwich_details);
        String json = sandwiches[position];
         sandwich = JsonUtils.parseSandwichJson(json);
        if (sandwich == null) {
            // Sandwich data unavailable
            closeOnError();
            return;
        }

        populateUI();
        Picasso.with(this)
                .load(sandwich.getImage())
                .placeholder(R.drawable.image1)
                .error(R.drawable.image1)
                .into(ingredientsIv);

        setTitle(sandwich.getMainName());
    }

    private void closeOnError() {
        finish();
        Toast.makeText(this, R.string.detail_error_message, Toast.LENGTH_SHORT).show();
    }

    //method tp populate the UI
    //first check if data is empty, if so setText to unknown else get call sandwich methods to
    //setText on the corresponding view
    private void populateUI() {

        if(sandwich.getPlaceOfOrigin().isEmpty()){
            placeOfOrigin.setText("Unknown place of origin");

        }else{
            placeOfOrigin.setText(sandwich.getPlaceOfOrigin());
        }

        if(sandwich.getDescription().isEmpty()){
                description.setText("Unknown description");
        }else{
                description.setText(sandwich.getDescription());
        }

        if(sandwich.getAlsoKnownAs().isEmpty()){
                alsoKnowAs.setText("Unknown other names");
        } else{
//                alsoKnowAs.setText(bindDataInArray(sandwich.getAlsoKnownAs()));
            alsoKnowAs.setText(TextUtils.join(", ",sandwich.getAlsoKnownAs()));
        }

        if(sandwich.getIngredients().isEmpty()){
                ingredients.setText("NO INGRIDIENTS FOUND");
        }
        else{
//                ingredients.setText(bindDataInArray(sandwich.getIngredients()));
            ingredients.setText(TextUtils.join(", ",sandwich.getIngredients()));
        }

    }

    //method to bind/append data in the list array into a string
//    private String bindDataInArray(List<String> array){
//        StringBuilder bindArray = new StringBuilder();
//        for(int i = 0; i < array.size();i++){
//            bindArray.append(array.get(i))
//            .append("\n");
//        }
//        String bindData = bindArray.toString();
//        return bindData;
//    }
}
