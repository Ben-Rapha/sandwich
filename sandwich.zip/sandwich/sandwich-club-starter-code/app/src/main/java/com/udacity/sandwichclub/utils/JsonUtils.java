package com.udacity.sandwichclub.utils;

import com.udacity.sandwichclub.model.Sandwich;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class JsonUtils {
    //fields/ variables of the JSON object in order to minimize errors
    private static final String NAME = "name";
    private static final String  MAIN_NAME  = "mainName";
    private static final String ALSO_KNOWN_AS = "alsoKnownAs";
    private static final String PLACE_OF_ORIGIN = "placeOfOrigin";
    private static final String DESCRIPTION = "description";
    private static final String INGREDIENTS = "ingredients";
    private static final String IMAGE = "image";

    public static Sandwich parseSandwichJson(String json) {
        //list to hold also unknown
        List<String> alsoKnownAsList = new ArrayList<String>();
        //list to hold ingredients
        List<String> ingredients = new ArrayList<String>();
        Sandwich sandWich = null;

        //try to get all data from the json object and if there's / are errors parsing catch exceptions
        try {
            JSONObject dataJson = new JSONObject(json);
            JSONObject name = dataJson.optJSONObject(NAME);
            String mainName = name.optString(MAIN_NAME);
            JSONArray alsoKnownAsArray = name.optJSONArray(ALSO_KNOWN_AS);
            String placeOfOrigin = dataJson.optString(PLACE_OF_ORIGIN);
            String description = dataJson.optString(DESCRIPTION);
            String image = dataJson.optString(IMAGE);
            JSONArray ingredientsArray = dataJson.optJSONArray(INGREDIENTS);
            alsoKnownAsList = goThroughJsonArray(alsoKnownAsArray);
            ingredients = goThroughJsonArray(ingredientsArray);
            sandWich = new Sandwich(mainName, alsoKnownAsList, placeOfOrigin, description, image, ingredients);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return sandWich;
    }

    //method to loop through a json array an append add into a s List
    private static   List<String> goThroughJsonArray( JSONArray array) {
        List<String> dummyList = new ArrayList<>();
        for(int i = 0; array.length() > i;i++){
            try {
                dummyList.add(array.getString(i));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return dummyList;
    }
}
